# garimasingh128.github.io

![Demo](video.gif)


![Author](https://img.shields.io/badge/author-garimasingh128-orange)
![License](https://img.shields.io/badge/license-MIT-brightgreen)
![Platform](https://img.shields.io/badge/platform-Visual%20Studio%20Code-blue)
![Maintained](https://img.shields.io/maintenance/yes/2020)
[![Codacy Badge](https://api.codacy.com/project/badge/Grade/e52b4d5ce490402a8adfe52eb45dc573)](https://app.codacy.com/manual/garimasingh128/garimasingh128.github.io?utm_source=github.com&utm_medium=referral&utm_content=garimasingh128/garimasingh128.github.io&utm_campaign=Badge_Grade_Dashboard)

My portfolio in form of a website with the links to all my social media accounts, my working and completed projects and my Resume.
link: https://garimasingh128.github.io
link: bit.ly/garimasingh
